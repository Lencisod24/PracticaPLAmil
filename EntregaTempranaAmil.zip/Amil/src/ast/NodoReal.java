package ast;

import semantico.TablaSimbolos;
import semantico.Tipos;

public class NodoReal extends Expresion {

    private String valor;

    public NodoReal(int fil, int col, String valor) {
        super(fil, col);
        this.valor = valor;
        this.kind = KindE.REAL;
    }

    public String getValor() {
        return valor;
    }

    @Override
    public String toString(String tab) {
        return tab + "Real: " + valor + "\n";
    }

    @Override
    public void chequea(TablaSimbolos ts) {
        this.setTipo(Tipos.REAL);
    }

    @Override
    public void generateCodeExpresion(StringBuilder sb, int indent) {
        sb.append("  ".repeat(indent))
                .append("f32.const ")
                .append(valor)
                .append("\n");
    }

    @Override
    public int asignarDelta(int dirPadre) {
        return dirPadre; // los literales no ocupan espacio en el marco
    }
}
