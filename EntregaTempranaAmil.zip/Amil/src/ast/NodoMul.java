package ast;

import semantico.ComprobadorTipos;
import semantico.TablaSimbolos;
import semantico.Tipos;

public class NodoMul extends ExpresionBinaria {
    public NodoMul(int fil, int col, Expresion opIzq, Expresion opDer) {
        super(fil, col, opIzq, opDer);
        this.kind = KindE.MUL;
    }

    @Override
    public String toString(String tab) {
        return tab + "Multiplicacion (*)\n" + opIzq().toString(tab + "  ") + opDer().toString(tab + "  ");
    }

    @Override
    public void chequea(TablaSimbolos ts) {
        // Evaluación ascendente
        if (opIzq() != null)
            opIzq().chequea(ts);
        if (opDer() != null)
            opDer().chequea(ts);

        // Extraemos los tipos
        String tipoIzq = (opIzq() != null && opIzq().getTipo() != null) ? opIzq().getTipo() : Tipos.ERROR;
        String tipoDer = (opDer() != null && opDer().getTipo() != null) ? opDer().getTipo() : Tipos.ERROR;

        if (tipoIzq.equals(Tipos.ERROR) || tipoDer.equals(Tipos.ERROR)) {
            this.setTipo(Tipos.ERROR);
            return;
        }

        // Ambos deben ser tipos numéricos
        if (!ComprobadorTipos.esNumerico(tipoDer) || !ComprobadorTipos.esNumerico(tipoIzq)) {
            System.err.println("Error Semántico [" + getFila() + ":" + getColumna() +
                    "]: Operación aritmética '*' inválida. Se esperaban tipos numéricos, pero se encontraron '" +
                    tipoIzq + "' y '" + tipoDer + "'.");
            this.setTipo(Tipos.ERROR);
            return;
        }

        // Asignamos el tipo resultante
        this.setTipo(ComprobadorTipos.inferirTipoAritmetico(tipoIzq, tipoDer));
    }

    @Override
    protected String opcodeEntero() {
        return "i32.mul";
    }

    @Override
    protected String opcodeReal() {
        return "f32.mul";
    }

    @Override
    public int asignarDelta(int dirPadre) {
        int dirLocal = opIzq().asignarDelta(dirPadre);
        dirLocal = opDer().asignarDelta(dirLocal);
        return dirLocal;
    }
}